'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function DailyTips() {
  const [language, setLanguage] = useState('en');
  const [currentTipIndex, setCurrentTipIndex] = useState(0);

  const content = {
    en: {
      title: 'Daily Vastu Tips',
      subtitle: 'Daily Wisdom for Positive Energy',
      todaysTip: 'Today\'s Tip',
      previousTip: 'Previous Tip',
      nextTip: 'Next Tip',
      category: 'Category',
      shareBtn: 'Share Tip'
    },
    hi: {
      title: 'दैनिक वास्तु सुझाव',
      subtitle: 'सकारात्मक ऊर्जा के लिए दैनिक ज्ञान',
      todaysTip: 'आज का सुझाव',
      previousTip: 'पिछला सुझाव',
      nextTip: 'अगला सुझाव',
      category: 'श्रेणी',
      shareBtn: 'सुझाव साझा करें'
    }
  };

  const dailyTips = [
    {
      id: 1,
      category: { en: 'Morning Rituals', hi: 'प्रातःकालीन अनुष्ठान' },
      tip: {
        en: 'Start your day by opening all windows and doors to let fresh air and positive energy flow into your home. Light a diya or candle in the North-East corner.',
        hi: 'अपने दिन की शुरुआत सभी खिड़कियां और दरवाजे खोलकर करें ताकि ताजी हवा और सकारात्मक ऊर्जा आपके घर में प्रवाहित हो सके। उत्तर-पूर्व कोने में दीया या मोमबत्ती जलाएं।'
      },
      icon: 'ri-sun-line',
      color: 'from-orange-400 to-yellow-500'
    },
    {
      id: 2,
      category: { en: 'Kitchen Vastu', hi: 'रसोई वास्तु' },
      tip: {
        en: 'While cooking, face East direction for better health and prosperity. Keep your kitchen clean and organized, especially the South-East corner where fire element resides.',
        hi: 'खाना बनाते समय पूर्व दिशा का सामना करें बेहतर स्वास्थ्य और समृद्धि के लिए। अपनी रसोई को साफ और व्यवस्थित रखें, विशेषकर दक्षिण-पूर्व कोना जहां अग्नि तत्व निवास करता है।'
      },
      icon: 'ri-restaurant-line',
      color: 'from-red-400 to-orange-500'
    },
    {
      id: 3,
      category: { en: 'Bedroom Energy', hi: 'शयनकक्ष ऊर्जा' },
      tip: {
        en: 'Place a pair of rose quartz crystals in your bedroom to enhance love and harmony. Avoid keeping electronic devices near your bed for better sleep quality.',
        hi: 'प्रेम और सामंजस्य बढ़ाने के लिए अपने शयनकक्ष में गुलाब क्वार्ट्ज क्रिस्टल की एक जोड़ी रखें। बेहतर नींद की गुणवत्ता के लिए अपने बिस्तर के पास इलेक्ट्रॉनिक उपकरण रखने से बचें।'
      },
      icon: 'ri-hotel-bed-line',
      color: 'from-blue-400 to-purple-500'
    },
    {
      id: 4,
      category: { en: 'Water Element', hi: 'जल तत्व' },
      tip: {
        en: 'Place a small water fountain or bowl of fresh water in the North-East corner of your home to attract wealth and positive energy. Change the water daily.',
        hi: 'धन और सकारात्मक ऊर्जा आकर्षित करने के लिए अपने घर के उत्तर-पूर्व कोने में एक छोटा पानी का फव्वारा या ताजे पानी का कटोरा रखें। पानी रोजाना बदलें।'
      },
      icon: 'ri-drop-line',
      color: 'from-cyan-400 to-blue-500'
    },
    {
      id: 5,
      category: { en: 'Plants & Nature', hi: 'पौधे और प्रकृति' },
      tip: {
        en: 'Keep money plants or bamboo plants in the South-East corner for financial growth. Avoid thorny plants inside the house as they create negative energy.',
        hi: 'वित्तीय विकास के लिए दक्षिण-पूर्व कोने में मनी प्लांट या बांस के पौधे रखें। घर के अंदर कांटेदार पौधे रखने से बचें क्योंकि वे नकारात्मक ऊर्जा पैदा करते हैं।'
      },
      icon: 'ri-plant-line',
      color: 'from-green-400 to-teal-500'
    },
    {
      id: 6,
      category: { en: 'Colors & Decor', hi: 'रंग और सजावट' },
      tip: {
        en: 'Use light and soothing colors in your living spaces. Yellow and orange in the kitchen, blue and green in bedrooms, and white in study areas work best.',
        hi: 'अपने रहने की जगहों में हल्के और शांत रंगों का उपयोग करें। रसोई में पीला और नारंगी, शयनकक्ष में नीला और हरा, और अध्ययन क्षेत्रों में सफेद सबसे अच्छा काम करता है।'
      },
      icon: 'ri-palette-line',
      color: 'from-purple-400 to-pink-500'
    },
    {
      id: 7,
      category: { en: 'Cleanliness', hi: 'स्वच्छता' },
      tip: {
        en: 'Keep your entrance clean and well-lit. A cluttered entrance blocks positive energy from entering your home. Place a welcome mat and some plants.',
        hi: 'अपने प्रवेश द्वार को साफ और अच्छी तरह से रोशन रखें। अव्यवस्थित प्रवेश द्वार सकारात्मक ऊर्जा को आपके घर में प्रवेश करने से रोकता है। स्वागत चटाई और कुछ पौधे रखें।'
      },
      icon: 'ri-broom-line',
      color: 'from-teal-400 to-cyan-500'
    }
  ];

  useEffect(() => {
    const today = new Date().getDay();
    setCurrentTipIndex(today % dailyTips.length);
  }, []);

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  const nextTip = () => {
    setCurrentTipIndex((prev) => (prev + 1) % dailyTips.length);
  };

  const prevTip = () => {
    setCurrentTipIndex((prev) => (prev - 1 + dailyTips.length) % dailyTips.length);
  };

  const currentTip = dailyTips[currentTipIndex];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <Link href="/" className="flex items-center space-x-3 cursor-pointer">
              <div className="w-10 h-10 bg-gradient-to-r from-orange-400 to-amber-500 rounded-full flex items-center justify-center">
                <i className="ri-home-heart-line text-white text-xl"></i>
              </div>
              <h1 className="text-2xl font-bold text-orange-600" style={{fontFamily: 'Pacifico, serif'}}>
                VastuGuide
              </h1>
            </Link>
          </div>
          <button
            onClick={toggleLanguage}
            className="flex items-center space-x-2 px-4 py-2 bg-orange-100 hover:bg-orange-200 rounded-full transition-colors cursor-pointer"
          >
            <i className="ri-translate-2 text-orange-600"></i>
            <span className="text-orange-600 font-medium whitespace-nowrap">
              {language === 'en' ? 'हिंदी' : 'English'}
            </span>
          </button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">{content[language].title}</h2>
          <p className="text-xl text-gray-600">{content[language].subtitle}</p>
        </div>

        {/* Today's Tip Card */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-8 border border-orange-100">
          <div className={`bg-gradient-to-r ${currentTip.color} p-6 text-white`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center">
                  <i className={`${currentTip.icon} text-3xl`}></i>
                </div>
                <div>
                  <h3 className="text-2xl font-bold">{content[language].todaysTip}</h3>
                  <p className="opacity-90">{content[language].category}: {currentTip.category[language]}</p>
                </div>
              </div>
              <div className="text-4xl font-bold opacity-50">
                #{currentTipIndex + 1}
              </div>
            </div>
          </div>

          <div className="p-8">
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              {currentTip.tip[language]}
            </p>

            <div className="flex items-center justify-between">
              <div className="flex space-x-4">
                <button
                  onClick={prevTip}
                  className="flex items-center space-x-2 px-4 py-2 bg-orange-100 hover:bg-orange-200 rounded-lg transition-colors cursor-pointer"
                >
                  <i className="ri-arrow-left-line text-orange-600"></i>
                  <span className="text-orange-600 whitespace-nowrap">{content[language].previousTip}</span>
                </button>
                <button
                  onClick={nextTip}
                  className="flex items-center space-x-2 px-4 py-2 bg-orange-100 hover:bg-orange-200 rounded-lg transition-colors cursor-pointer"
                >
                  <span className="text-orange-600 whitespace-nowrap">{content[language].nextTip}</span>
                  <i className="ri-arrow-right-line text-orange-600"></i>
                </button>
              </div>
              <button className="flex items-center space-x-2 px-4 py-2 bg-green-100 hover:bg-green-200 rounded-lg transition-colors cursor-pointer">
                <i className="ri-share-line text-green-600"></i>
                <span className="text-green-600 whitespace-nowrap">{content[language].shareBtn}</span>
              </button>
            </div>
          </div>
        </div>

        {/* All Tips Grid */}
        <div className="mb-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6">All Tips</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {dailyTips.map((tip, index) => (
              <div
                key={tip.id}
                onClick={() => setCurrentTipIndex(index)}
                className={`bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all cursor-pointer border ${
                  index === currentTipIndex ? 'border-orange-300 ring-2 ring-orange-200' : 'border-gray-200'
                }`}
              >
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 bg-gradient-to-r ${tip.color} rounded-lg flex items-center justify-center`}>
                    <i className={`${tip.icon} text-white text-xl`}></i>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-800 mb-1">{tip.category[language]}</h4>
                    <p className="text-gray-600 text-sm line-clamp-3">
                      {tip.tip[language].substring(0, 120)}...
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Tip Categories */}
        <div className="bg-orange-50 rounded-2xl p-6 border border-orange-100">
          <h3 className="text-xl font-bold text-orange-800 mb-4">Tip Categories</h3>
          <div className="flex flex-wrap gap-3">
            {Array.from(new Set(dailyTips.map(tip => tip.category[language]))).map((category, index) => (
              <span key={index} className="px-4 py-2 bg-white text-orange-700 rounded-full text-sm shadow-sm">
                {category}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}