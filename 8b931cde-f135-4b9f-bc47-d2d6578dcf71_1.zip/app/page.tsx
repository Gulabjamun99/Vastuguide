'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Home() {
  const [language, setLanguage] = useState('en');

  const content = {
    en: {
      title: 'VastuGuide',
      subtitle: 'Your Personal Vastu Shastra Consultant',
      startCheck: 'Start Vastu Check',
      roomWise: 'Room-wise Vastu',
      directionWise: 'Direction-wise Vastu',
      dailyTips: 'Daily Tips',
      remedies: 'Remedies',
      askBot: 'Ask VastuBot'
    },
    hi: {
      title: 'वास्तु गाइड',
      subtitle: 'आपका व्यक्तिगत वास्तु शास्त्र सलाहकार',
      startCheck: 'वास्तु जांच शुरू करें',
      roomWise: 'कमरे के अनुसार वास्तु',
      directionWise: 'दिशा के अनुसार वास्तु',
      dailyTips: 'दैनिक सुझाव',
      remedies: 'उपाय',
      askBot: 'वास्तु बॉट से पूछें'
    }
  };

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-orange-400 to-amber-500 rounded-full flex items-center justify-center">
              <i className="ri-home-heart-line text-white text-xl"></i>
            </div>
            <h1 className="text-2xl font-bold text-orange-600" style={{fontFamily: 'Pacifico, serif'}}>
              {content[language].title}
            </h1>
          </div>
          <button
            onClick={toggleLanguage}
            className="flex items-center space-x-2 px-4 py-2 bg-orange-100 hover:bg-orange-200 rounded-full transition-colors cursor-pointer"
          >
            <i className="ri-translate-2 text-orange-600"></i>
            <span className="text-orange-600 font-medium whitespace-nowrap">
              {language === 'en' ? 'हिंदी' : 'English'}
            </span>
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div 
        className="relative h-96 flex items-center justify-center text-center"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Ancient%20Indian%20architecture%20with%20traditional%20geometric%20patterns%2C%20golden%20sunrise%20light%20filtering%20through%20pillars%2C%20peaceful%20meditation%20space%20with%20lotus%20symbols%2C%20warm%20orange%20and%20cream%20colors%2C%20sacred%20geometry%20designs%2C%20spiritual%20ambiance%20with%20soft%20shadows%2C%20architectural%20details%20showing%20harmony%20and%20balance%2C%20minimalist%20background%20with%20subtle%20textures&width=1200&height=400&seq=vastu-hero&orientation=landscape')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-orange-900/70 to-amber-900/50"></div>
        <div className="relative z-10 text-white max-w-4xl px-4">
          <h2 className="text-5xl font-bold mb-4">{content[language].title}</h2>
          <p className="text-xl opacity-90">{content[language].subtitle}</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Main Navigation Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          <Link href="/vastu-check" className="group cursor-pointer">
            <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 border border-orange-100 group-hover:border-orange-300">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-amber-500 rounded-xl flex items-center justify-center mb-4">
                <i className="ri-search-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">{content[language].startCheck}</h3>
              <p className="text-gray-600">Get personalized Vastu analysis for your property</p>
            </div>
          </Link>

          <Link href="/room-wise" className="group cursor-pointer">
            <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 border border-orange-100 group-hover:border-orange-300">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-amber-500 rounded-xl flex items-center justify-center mb-4">
                <i className="ri-home-4-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">{content[language].roomWise}</h3>
              <p className="text-gray-600">Explore Vastu guidelines for each room</p>
            </div>
          </Link>

          <Link href="/direction-wise" className="group cursor-pointer">
            <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 border border-orange-100 group-hover:border-orange-300">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-amber-500 rounded-xl flex items-center justify-center mb-4">
                <i className="ri-compass-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">{content[language].directionWise}</h3>
              <p className="text-gray-600">Learn about directional Vastu principles</p>
            </div>
          </Link>

          <Link href="/daily-tips" className="group cursor-pointer">
            <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 border border-orange-100 group-hover:border-orange-300">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-amber-500 rounded-xl flex items-center justify-center mb-4">
                <i className="ri-lightbulb-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">{content[language].dailyTips}</h3>
              <p className="text-gray-600">Daily Vastu tips for positive energy</p>
            </div>
          </Link>

          <Link href="/remedies" className="group cursor-pointer">
            <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 border border-orange-100 group-hover:border-orange-300">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-amber-500 rounded-xl flex items-center justify-center mb-4">
                <i className="ri-magic-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">{content[language].remedies}</h3>
              <p className="text-gray-600">Effective Vastu remedies and solutions</p>
            </div>
          </Link>

          <Link href="/chatbot" className="group cursor-pointer">
            <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 border border-orange-100 group-hover:border-orange-300">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-amber-500 rounded-xl flex items-center justify-center mb-4">
                <i className="ri-robot-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">{content[language].askBot}</h3>
              <p className="text-gray-600">Get instant answers to your Vastu questions</p>
            </div>
          </Link>
        </div>

        {/* Banner Advertisement */}
        <div className="bg-gradient-to-r from-orange-100 to-amber-100 rounded-2xl p-6 text-center border border-orange-200">
          <div className="text-gray-600 text-sm mb-2">Advertisement</div>
          <div className="text-lg font-semibold text-orange-700">
            Transform Your Space with Professional Vastu Consultation
          </div>
          <div className="text-orange-600 mt-2">Book Your Session Today!</div>
        </div>
      </div>

      {/* Floating Chat Button */}
      <Link href="/chatbot">
        <div className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-orange-500 to-amber-500 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all cursor-pointer">
          <i className="ri-chat-3-line text-white text-xl"></i>
        </div>
      </Link>
    </div>
  );
}