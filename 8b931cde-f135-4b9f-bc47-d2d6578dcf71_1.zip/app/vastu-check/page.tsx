'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function VastuCheck() {
  const [language, setLanguage] = useState('en');
  const [formData, setFormData] = useState({
    name: '',
    propertyFacing: '',
    propertyType: '',
    floorPlan: null
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');

  const content = {
    en: {
      title: 'Start Vastu Check',
      subtitle: 'Get Personalized Vastu Analysis',
      name: 'Full Name',
      propertyFacing: 'Property Facing Direction',
      propertyType: 'Property Type',
      floorPlan: 'Upload Floor Plan',
      residential: 'Residential',
      commercial: 'Commercial',
      submit: 'Submit for Analysis',
      submitting: 'Submitting...',
      success: 'Your Vastu check request has been submitted successfully!',
      error: 'Please fill all required fields.',
      nameHint: 'Enter your full name',
      planHint: 'Upload image or PDF of your floor plan (optional)'
    },
    hi: {
      title: 'वास्तु जांच शुरू करें',
      subtitle: 'व्यक्तिगत वास्तु विश्लेषण प्राप्त करें',
      name: 'पूरा नाम',
      propertyFacing: 'संपत्ति की दिशा',
      propertyType: 'संपत्ति का प्रकार',
      floorPlan: 'फ्लोर प्लान अपलोड करें',
      residential: 'आवासीय',
      commercial: 'व्यावसायिक',
      submit: 'विश्लेषण के लिए जमा करें',
      submitting: 'जमा कर रहे हैं...',
      success: 'आपका वास्तु जांच अनुरोध सफलतापूर्वक जमा हो गया है!',
      error: 'कृपया सभी आवश्यक फील्ड भरें।',
      nameHint: 'अपना pूरा नाम दर्ज करें',
      planHint: 'अपने फ्लोर प्लान की छवि या PDF अपलोड करें (वैकल्पिक)'
    }
  };

  const directions = [
    { value: 'north', label: { en: 'North', hi: 'उत्तर' } },
    { value: 'northeast', label: { en: 'North-East', hi: 'उत्तर-पूर्व' } },
    { value: 'east', label: { en: 'East', hi: 'पूर्व' } },
    { value: 'southeast', label: { en: 'South-East', hi: 'दक्षिण-पूर्व' } },
    { value: 'south', label: { en: 'South', hi: 'दक्षिण' } },
    { value: 'southwest', label: { en: 'South-West', hi: 'दक्षिण-पश्चिम' } },
    { value: 'west', label: { en: 'West', hi: 'पश्चिम' } },
    { value: 'northwest', label: { en: 'North-West', hi: 'उत्तर-पश्चिम' } }
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.propertyFacing || !formData.propertyType) {
      setSubmitMessage(content[language].error);
      return;
    }

    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setSubmitMessage(content[language].success);
      setIsSubmitting(false);
      setFormData({ name: '', propertyFacing: '', propertyType: '', floorPlan: null });
    }, 2000);
  };

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <Link href="/" className="flex items-center space-x-3 cursor-pointer">
              <div className="w-10 h-10 bg-gradient-to-r from-orange-400 to-amber-500 rounded-full flex items-center justify-center">
                <i className="ri-home-heart-line text-white text-xl"></i>
              </div>
              <h1 className="text-2xl font-bold text-orange-600" style={{fontFamily: 'Pacifico, serif'}}>
                VastuGuide
              </h1>
            </Link>
          </div>
          <button
            onClick={toggleLanguage}
            className="flex items-center space-x-2 px-4 py-2 bg-orange-100 hover:bg-orange-200 rounded-full transition-colors cursor-pointer"
          >
            <i className="ri-translate-2 text-orange-600"></i>
            <span className="text-orange-600 font-medium whitespace-nowrap">
              {language === 'en' ? 'हिंदी' : 'English'}
            </span>
          </button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">{content[language].title}</h2>
          <p className="text-xl text-gray-600">{content[language].subtitle}</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 border border-orange-100">
          <form id="vastu-check-form" onSubmit={handleSubmit} className="space-y-6">
            {/* Name Field */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {content[language].name} *
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder={content[language].nameHint}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 text-sm"
                required
              />
            </div>

            {/* Property Facing */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {content[language].propertyFacing} *
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {directions.map((direction) => (
                  <label key={direction.value} className="flex items-center cursor-pointer">
                    <input
                      type="radio"
                      name="propertyFacing"
                      value={direction.value}
                      checked={formData.propertyFacing === direction.value}
                      onChange={(e) => setFormData({...formData, propertyFacing: e.target.value})}
                      className="mr-2 text-orange-500 focus:ring-orange-500"
                      required
                    />
                    <span className="text-sm">{direction.label[language]}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Property Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {content[language].propertyType} *
              </label>
              <div className="flex space-x-6">
                <label className="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    name="propertyType"
                    value="residential"
                    checked={formData.propertyType === 'residential'}
                    onChange={(e) => setFormData({...formData, propertyType: e.target.value})}
                    className="mr-2 text-orange-500 focus:ring-orange-500"
                    required
                  />
                  <span className="text-sm">{content[language].residential}</span>
                </label>
                <label className="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    name="propertyType"
                    value="commercial"
                    checked={formData.propertyType === 'commercial'}
                    onChange={(e) => setFormData({...formData, propertyType: e.target.value})}
                    className="mr-2 text-orange-500 focus:ring-orange-500"
                    required
                  />
                  <span className="text-sm">{content[language].commercial}</span>
                </label>
              </div>
            </div>

            {/* Floor Plan Upload */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {content[language].floorPlan}
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-orange-400 transition-colors">
                <i className="ri-upload-cloud-2-line text-4xl text-gray-400 mb-2"></i>
                <p className="text-sm text-gray-600 mb-2">{content[language].planHint}</p>
                <input
                  type="file"
                  name="floorPlan"
                  accept="image/*,.pdf"
                  onChange={(e) => setFormData({...formData, floorPlan: e.target.files[0]})}
                  className="hidden"
                  id="floorPlan"
                />
                <label htmlFor="floorPlan" className="inline-block px-4 py-2 bg-orange-100 text-orange-600 rounded-lg cursor-pointer hover:bg-orange-200 transition-colors whitespace-nowrap">
                  Choose File
                </label>
                {formData.floorPlan && (
                  <p className="text-sm text-green-600 mt-2">
                    {formData.floorPlan.name}
                  </p>
                )}
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-orange-500 to-amber-500 text-white py-4 px-6 rounded-lg font-semibold hover:from-orange-600 hover:to-amber-600 transition-all duration-300 disabled:opacity-50 whitespace-nowrap cursor-pointer"
              >
                {isSubmitting ? content[language].submitting : content[language].submit}
              </button>
            </div>

            {/* Submission Message */}
            {submitMessage && (
              <div className={`p-4 rounded-lg text-center ${
                submitMessage.includes('successfully') || submitMessage.includes('सफलतापूर्वक')
                  ? 'bg-green-100 text-green-700'
                  : 'bg-red-100 text-red-700'
              }`}>
                {submitMessage}
              </div>
            )}
          </form>
        </div>

        {/* Additional Info */}
        <div className="mt-8 bg-orange-50 rounded-2xl p-6 border border-orange-100">
          <h3 className="text-lg font-semibold text-orange-800 mb-3">
            What happens next?
          </h3>
          <ul className="space-y-2 text-orange-700">
            <li className="flex items-start">
              <i className="ri-check-line text-orange-500 mt-1 mr-2"></i>
              Our Vastu expert will analyze your property details
            </li>
            <li className="flex items-start">
              <i className="ri-check-line text-orange-500 mt-1 mr-2"></i>
              You'll receive a detailed Vastu report via email
            </li>
            <li className="flex items-start">
              <i className="ri-check-line text-orange-500 mt-1 mr-2"></i>
              Personalized remedies and suggestions will be provided
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}