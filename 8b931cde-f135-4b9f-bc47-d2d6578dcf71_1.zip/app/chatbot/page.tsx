'use client';

import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';

export default function Chatbot() {
  const [language, setLanguage] = useState('en');
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const content = {
    en: {
      title: 'Ask VastuBot',
      subtitle: 'Get Instant Answers to Your Vastu Questions',
      placeholder: 'Ask your Vastu question here...',
      send: 'Send',
      welcomeMsg: 'Hello! I\'m VastuBot, your personal Vastu consultant. Ask me anything about Vastu Shastra!',
      typing: 'VastuBot is typing...',
      quickQuestions: 'Quick Questions',
      examples: [
        'Where should I place my kitchen?',
        'Which color is best for North direction?',
        'How to fix toilet in NE corner?',
        'Best direction for main entrance?',
        'What to do for financial problems?'
      ]
    },
    hi: {
      title: 'वास्तु बॉट से पूछें',
      subtitle: 'अपने वास्तु प्रश्नों के तुरंत उत्तर पाएं',
      placeholder: 'यहाँ अपना वास्तु प्रश्न पूछें...',
      send: 'भेजें',
      welcomeMsg: 'नमस्ते! मैं वास्तु बॉट हूँ, आपका व्यक्तिगत वास्तु सलाहकार। मुझसे वास्तु शास्त्र के बारे में कुछ भी पूछें!',
      typing: 'वास्तु बॉट टाइप कर रहा है...',
      quickQuestions: 'त्वरित प्रश्न',
      examples: [
        'मुझे अपनी रसोई कहाँ रखनी चाहिए?',
        'उत्तर दिशा के लिए कौन सा रंग सबसे अच्छा है?',
        'उत्तर-पूर्व कोने में शौचालय को कैसे ठीक करें?',
        'मुख्य प्रवेश द्वार के लिए सबसे अच्छी दिशा?',
        'वित्तीय समस्याओं के लिए क्या करें?'
      ]
    }
  };

  const vastubotResponses = {
    en: {
      kitchen: "For kitchen placement, the ideal direction is South-East (Agni corner). If not possible, East or North-West are alternatives. Avoid North-East, North, and South-West directions for kitchen. The cooking stove should face East while cooking for better health and prosperity.",
      
      north: "North direction is governed by Kubera (God of Wealth) and represents the water element. Best colors for North are blue, white, light green, and silver. This direction is ideal for main entrance, cash counter, study area, and water features. Avoid heavy structures here.",
      
      toilet_ne: "Toilet in North-East is a major Vastu dosha. Remedies: 1) Keep a bowl of sea salt that you change weekly, 2) Place a small plant outside the bathroom, 3) Keep the door closed always, 4) Use an exhaust fan, 5) Paint in light colors, 6) Burn camphor weekly for purification.",
      
      entrance: "The best directions for main entrance are North, North-East, and East. These bring positive energy, wealth, and prosperity. Avoid South, South-West, and North-West entrances. If unavoidable, use remedies like red mat, brass nameplate, and traditional toran.",
      
      financial: "For financial prosperity: 1) Keep cash/safe in North direction, 2) Place a water fountain in North-East, 3) Keep your kitchen in South-East, 4) Avoid clutter in North area, 5) Place money plant in South-East corner, 6) Keep entrance well-lit and clean.",
      
      default: "I'm here to help with all your Vastu questions! You can ask me about room directions, color recommendations, remedies for Vastu doshas, or any specific Vastu problems you're facing. What would you like to know?"
    },
    hi: {
      kitchen: "रसोई के लिए आदर्श दिशा दक्षिण-पूर्व (अग्नि कोना) है। यदि संभव नहीं है, तो पूर्व या उत्तर-पश्चिम विकल्प हैं। रसोई के लिए उत्तर-पूर्व, उत्तर और दक्षिण-पश्चिम दिशाओं से बचें। बेहतर स्वास्थ्य और समृद्धि के लिए खाना बनाते समय चूल्हे का मुंह पूर्व की ओर होना चाहिए।",
      
      north: "उत्तर दिशा कुबेर (धन के देवता) द्वारा शासित है और जल तत्व का प्रतिनिधित्व करती है। उत्तर के लिए सबसे अच्छे रंग नीले, सफेद, हल्के हरे और चांदी हैं। यह दिशा मुख्य प्रवेश द्वार, कैश काउंटर, अध्ययन क्षेत्र और जल सुविधाओं के लिए आदर्श है। यहाँ भारी संरचनाओं से बचें।",
      
      toilet_ne: "उत्तर-पूर्व में शौचालय एक प्रमुख वास्तु दोष है। उपाय: 1) समुद्री नमक का कटोरा रखें जिसे आप साप्ताहिक बदलते हैं, 2) बाथरूम के बाहर एक छोटा पौधा रखें, 3) दरवाजा हमेशा बंद रखें, 4) एग्जॉस्ट फैन का उपयोग करें, 5) हल्के रंगों में रंग करें, 6) शुद्धिकरण के लिए साप्ताहिक कपूर जलाएं।",
      
      entrance: "मुख्य प्रवेश द्वार के लिए सबसे अच्छी दिशाएं उत्तर, उत्तर-पूर्व और पूर्व हैं। ये सकारात्मक ऊर्जा, धन और समृद्धि लाती हैं। दक्षिण, दक्षिण-पश्चिम और उत्तर-पश्चिम प्रवेश द्वार से बचें। यदि अपरिहार्य है, तो लाल चटाई, पीतल की नेमप्लेट और पारंपरिक तोरण जैसे उपाय करें।",
      
      financial: "वित्तीय समृद्धि के लिए: 1) उत्तर दिशा में नकदी/तिजोरी रखें, 2) उत्तर-पूर्व में पानी का फव्वारा रखें, 3) अपनी रसोई दक्षिण-पूर्व में रखें, 4) उत्तर क्षेत्र में अव्यवस्था से बचें, 5) दक्षिण-पूर्व कोने में मनी प्लांट रखें, 6) प्रवेश द्वार को अच्छी तरह से रोशन और साफ रखें।",
      
      default: "मैं आपके सभी वास्तु प्रश्नों में मदद करने के लिए यहाँ हूँ! आप मुझसे कमरों की दिशाओं, रंग की सिफारिशों, वास्तु दोषों के उपायों, या किसी भी विशिष्ट वास्तु समस्याओं के बारे में पूछ सकते हैं। आप क्या जानना चाहेंगे?"
    }
  };

  useEffect(() => {
    // Initial welcome message
    setMessages([{
      id: 1,
      text: content[language].welcomeMsg,
      sender: 'bot',
      timestamp: new Date()
    }]);
  }, [language]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const getVastuBotResponse = (userMessage) => {
    const message = userMessage.toLowerCase();
    const responses = vastubotResponses[language];
    
    if (message.includes('kitchen') || message.includes('रसोई')) {
      return responses.kitchen;
    } else if (message.includes('north') || message.includes('उत्तर')) {
      return responses.north;
    } else if ((message.includes('toilet') || message.includes('bathroom') || message.includes('शौचालय')) && 
               (message.includes('north-east') || message.includes('ne') || message.includes('उत्तर-पूर्व'))) {
      return responses.toilet_ne;
    } else if (message.includes('entrance') || message.includes('door') || message.includes('प्रवेश') || message.includes('दरवाजा')) {
      return responses.entrance;
    } else if (message.includes('money') || message.includes('financial') || message.includes('wealth') || 
               message.includes('धन') || message.includes('पैसा') || message.includes('वित्तीय')) {
      return responses.financial;
    } else {
      return responses.default;
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage = {
      id: Date.now(),
      text: inputMessage,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate bot typing delay
    setTimeout(() => {
      const botResponse = {
        id: Date.now() + 1,
        text: getVastuBotResponse(inputMessage),
        sender: 'bot',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const handleQuickQuestion = (question) => {
    setInputMessage(question);
  };

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 flex flex-col">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <Link href="/" className="flex items-center space-x-3 cursor-pointer">
              <div className="w-10 h-10 bg-gradient-to-r from-orange-400 to-amber-500 rounded-full flex items-center justify-center">
                <i className="ri-home-heart-line text-white text-xl"></i>
              </div>
              <h1 className="text-2xl font-bold text-orange-600" style={{fontFamily: 'Pacifico, serif'}}>
                VastuGuide
              </h1>
            </Link>
          </div>
          <button
            onClick={toggleLanguage}
            className="flex items-center space-x-2 px-4 py-2 bg-orange-100 hover:bg-orange-200 rounded-full transition-colors cursor-pointer"
          >
            <i className="ri-translate-2 text-orange-600"></i>
            <span className="text-orange-600 font-medium whitespace-nowrap">
              {language === 'en' ? 'हिंदी' : 'English'}
            </span>
          </button>
        </div>
      </div>

      {/* Chat Header */}
      <div className="bg-white border-b px-4 py-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">{content[language].title}</h2>
          <p className="text-gray-600">{content[language].subtitle}</p>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 max-w-4xl mx-auto w-full px-4 py-6 overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto space-y-4 mb-4" style={{ maxHeight: 'calc(100vh - 300px)' }}>
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                message.sender === 'user'
                  ? 'bg-orange-500 text-white'
                  : 'bg-white text-gray-800 shadow-md border border-orange-100'
              }`}>
                {message.sender === 'bot' && (
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="w-6 h-6 bg-gradient-to-r from-orange-400 to-amber-500 rounded-full flex items-center justify-center">
                      <i className="ri-robot-line text-white text-xs"></i>
                    </div>
                    <span className="text-xs font-medium text-orange-600">VastuBot</span>
                  </div>
                )}
                <p className="text-sm leading-relaxed">{message.text}</p>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white text-gray-800 shadow-md border border-orange-100 px-4 py-3 rounded-2xl max-w-xs">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="w-6 h-6 bg-gradient-to-r from-orange-400 to-amber-500 rounded-full flex items-center justify-center">
                    <i className="ri-robot-line text-white text-xs"></i>
                  </div>
                  <span className="text-xs font-medium text-orange-600">VastuBot</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-orange-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-orange-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                  <div className="w-2 h-2 bg-orange-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                  <span className="text-xs text-gray-500 ml-2">{content[language].typing}</span>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Questions */}
        <div className="mb-4">
          <h3 className="text-sm font-medium text-gray-700 mb-3">{content[language].quickQuestions}:</h3>
          <div className="flex flex-wrap gap-2">
            {content[language].examples.map((question, index) => (
              <button
                key={index}
                onClick={() => handleQuickQuestion(question)}
                className="px-3 py-2 bg-orange-100 hover:bg-orange-200 text-orange-700 rounded-full text-xs transition-colors cursor-pointer whitespace-nowrap"
              >
                {question}
              </button>
            ))}
          </div>
        </div>

        {/* Input Area */}
        <div className="flex space-x-3 bg-white p-4 rounded-2xl shadow-md border border-orange-100">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder={content[language].placeholder}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 text-sm"
          />
          <button
            onClick={handleSendMessage}
            disabled={!inputMessage.trim()}
            className="px-6 py-2 bg-gradient-to-r from-orange-500 to-amber-500 text-white rounded-lg hover:from-orange-600 hover:to-amber-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
          >
            <i className="ri-send-plane-line mr-2"></i>
            {content[language].send}
          </button>
        </div>
      </div>
    </div>
  );
}