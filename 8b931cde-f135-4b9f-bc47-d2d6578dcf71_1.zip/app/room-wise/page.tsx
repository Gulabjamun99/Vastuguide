'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function RoomWise() {
  const [language, setLanguage] = useState('en');
  const [selectedRoom, setSelectedRoom] = useState(null);

  const content = {
    en: {
      title: 'Room-wise Vastu',
      subtitle: 'Explore Vastu Guidelines for Each Room',
      idealDirection: 'Ideal Direction',
      dos: 'Do\'s',
      donts: 'Don\'ts',
      remedies: 'Remedies',
      colors: 'Suitable Colors',
      back: 'Back to Rooms'
    },
    hi: {
      title: 'कमरे के अनुसार वास्तु',
      subtitle: 'प्रत्येक कमरे के लिए वास्तु दिशानिर्देश देखें',
      idealDirection: 'आदर्श दिशा',
      dos: 'करें',
      donts: 'न करें',
      remedies: 'उपाय',
      colors: 'उपयुक्त रंग',
      back: 'कमरों पर वापस जाएं'
    }
  };

  const rooms = [
    {
      id: 'kitchen',
      name: { en: 'Kitchen', hi: 'रसोई' },
      icon: 'ri-restaurant-line',
      color: 'from-red-400 to-orange-500',
      idealDirection: { en: 'South-East', hi: 'दक्षिण-पूर्व' },
      dos: {
        en: ['Place stove in South-East corner', 'Keep kitchen clean and well-ventilated', 'Use bright lighting', 'Store water in North-East'],
        hi: ['चूल्हे को दक्षिण-पूर्व कोने में रखें', 'रसोई को साफ और हवादार रखें', 'उज्ज्वल रोशनी का उपयोग करें', 'उत्तर-पूर्व में पानी स्टोर करें']
      },
      donts: {
        en: ['Avoid kitchen in North-East', 'Don\'t place stove opposite to sink', 'Avoid dark colors', 'Don\'t keep dustbin near stove'],
        hi: ['उत्तर-पूर्व में रसोई से बचें', 'चूल्हे को सिंक के सामने न रखें', 'गहरे रंगों से बचें', 'चूल्हे के पास कूड़ेदान न रखें']
      },
      remedies: {
        en: ['Place red flowers in South-East', 'Hang wind chimes', 'Use yellow or orange colors', 'Keep herbs like basil'],
        hi: ['दक्षिण-पूर्व में लाल फूल रखें', 'विंड चाइम्स लटकाएं', 'पीले या नारंगी रंग का उपयोग करें', 'तुलसी जैसी जड़ी-बूटियां रखें']
      },
      colors: {
        en: ['Yellow', 'Orange', 'Red', 'Light Green'],
        hi: ['पीला', 'नारंगी', 'लाल', 'हल्का हरा']
      }
    },
    {
      id: 'bedroom',
      name: { en: 'Bedroom', hi: 'शयनकक्ष' },
      icon: 'ri-hotel-bed-line',
      color: 'from-blue-400 to-purple-500',
      idealDirection: { en: 'South-West', hi: 'दक्षिण-पश्चिम' },
      dos: {
        en: ['Place bed in South-West', 'Keep room clean and peaceful', 'Use soft lighting', 'Have proper ventilation'],
        hi: ['बिस्तर को दक्षिण-पश्चिम में रखें', 'कमरे को साफ और शांत रखें', 'मुलायम रोशनी का उपयोग करें', 'उचित वेंटिलेशन रखें']
      },
      donts: {
        en: ['Avoid mirror facing bed', 'Don\'t place electronics near bed', 'Avoid clutter under bed', 'Don\'t use bright colors'],
        hi: ['बिस्तर के सामने आईना न रखें', 'बिस्तर के पास इलेक्ट्रॉनिक्स न रखें', 'बिस्तर के नीचे अव्यवस्था से बचें', 'चमकीले रंगों का उपयोग न करें']
      },
      remedies: {
        en: ['Use rose quartz for love', 'Place pairs of objects', 'Keep fresh flowers', 'Use lavender for peace'],
        hi: ['प्रेम के लिए गुलाब क्वार्ट्ज का उपयोग करें', 'वस्तुओं के जोड़े रखें', 'ताजे फूल रखें', 'शांति के लिए लैवेंडर का उपयोग करें']
      },
      colors: {
        en: ['Light Blue', 'Pink', 'Cream', 'Light Green'],
        hi: ['हल्का नीला', 'गुलाबी', 'क्रीम', 'हल्का हरा']
      }
    },
    {
      id: 'living-room',
      name: { en: 'Living Room', hi: 'बैठक' },
      icon: 'ri-sofa-line',
      color: 'from-green-400 to-teal-500',
      idealDirection: { en: 'North or East', hi: 'उत्तर या पूर्व' },
      dos: {
        en: ['Place furniture in South-West', 'Keep center space open', 'Use bright colors', 'Have good lighting'],
        hi: ['फर्नीचर को दक्षिण-पश्चिम में रखें', 'केंद्रीय स्थान खुला रखें', 'चमकीले रंगों का उपयोग करें', 'अच्छी रोशनी रखें']
      },
      donts: {
        en: ['Avoid heavy furniture in North-East', 'Don\'t block natural light', 'Avoid dark corners', 'Don\'t clutter space'],
        hi: ['उत्तर-पूर्व में भारी फर्नीचर से बचें', 'प्राकृतिक प्रकाश को न रोकें', 'अंधेरे कोनों से बचें', 'जगह को अव्यवस्थित न करें']
      },
      remedies: {
        en: ['Place plants in East', 'Use mirrors to expand space', 'Keep fresh air flowing', 'Display family photos'],
        hi: ['पूर्व में पौधे रखें', 'स्थान बढ़ाने के लिए आईने का उपयोग करें', 'ताजी हवा का प्रवाह रखें', 'पारिवारिक तस्वीरें प्रदर्शित करें']
      },
      colors: {
        en: ['White', 'Light Yellow', 'Light Green', 'Cream'],
        hi: ['सफेद', 'हल्का पीला', 'हल्का हरा', 'क्रीम']
      }
    },
    {
      id: 'bathroom',
      name: { en: 'Bathroom', hi: 'स्नानघर' },
      icon: 'ri-drop-line',
      color: 'from-cyan-400 to-blue-500',
      idealDirection: { en: 'West or North-West', hi: 'पश्चिम या उत्तर-पश्चिम' },
      dos: {
        en: ['Keep bathroom clean and dry', 'Use exhaust fan', 'Place in West direction', 'Keep door closed'],
        hi: ['बाथरूम को साफ और सूखा रखें', 'एग्जॉस्ट फैन का उपयोग करें', 'पश्चिम दिशा में रखें', 'दरवाजा बंद रखें']
      },
      donts: {
        en: ['Avoid bathroom in North-East', 'Don\'t share wall with kitchen', 'Avoid keeping plants inside', 'Don\'t use dark tiles'],
        hi: ['उत्तर-पूर्व में बाथरूम से बचें', 'रसोई के साथ दीवार साझा न करें', 'अंदर पौधे रखने से बचें', 'गहरी टाइलों का उपयोग न करें']
      },
      remedies: {
        en: ['Use sea salt for purification', 'Place small plants outside', 'Use light colors', 'Keep good ventilation'],
        hi: ['शुद्धिकरण के लिए समुद्री नमक का उपयोग करें', 'बाहर छोटे पौधे रखें', 'हल्के रंगों का उपयोग करें', 'अच्छा वेंटिलेशन रखें']
      },
      colors: {
        en: ['White', 'Light Blue', 'Light Green', 'Cream'],
        hi: ['सफेद', 'हल्का नीला', 'हल्का हरा', 'क्रीम']
      }
    },
    {
      id: 'pooja-room',
      name: { en: 'Pooja Room', hi: 'पूजा कक्ष' },
      icon: 'ri-flower-line',
      color: 'from-yellow-400 to-orange-500',
      idealDirection: { en: 'North-East', hi: 'उत्तर-पूर्व' },
      dos: {
        en: ['Place in North-East corner', 'Keep clean and sacred', 'Use natural materials', 'Face East while praying'],
        hi: ['उत्तर-पूर्व कोने में रखें', 'साफ और पवित्र रखें', 'प्राकृतिक सामग्री का उपयोग करें', 'प्रार्थना करते समय पूर्व की ओर मुंह करें']
      },
      donts: {
        en: ['Avoid toilet nearby', 'Don\'t place in bedroom', 'Avoid artificial flowers', 'Don\'t keep broken idols'],
        hi: ['पास में शौचालय से बचें', 'शयनकक्ष में न रखें', 'कृत्रिम फूलों से बचें', 'टूटी मूर्तियां न रखें']
      },
      remedies: {
        en: ['Light lamp daily', 'Use camphor and incense', 'Keep fresh flowers', 'Sprinkle holy water'],
        hi: ['रोज दीया जलाएं', 'कपूर और अगरबत्ती का उपयोग करें', 'ताजे फूल रखें', 'पवित्र जल छिड़कें']
      },
      colors: {
        en: ['White', 'Yellow', 'Light Orange', 'Saffron'],
        hi: ['सफेद', 'पीला', 'हल्का नारंगी', 'केसरिया']
      }
    },
    {
      id: 'study-room',
      name: { en: 'Study Room', hi: 'अध्ययन कक्ष' },
      icon: 'ri-book-line',
      color: 'from-indigo-400 to-purple-500',
      idealDirection: { en: 'East or North', hi: 'पूर्व या उत्तर' },
      dos: {
        en: ['Face East while studying', 'Keep books organized', 'Use good lighting', 'Maintain cleanliness'],
        hi: ['पढ़ते समय पूर्व की ओर मुंह करें', 'किताबों को व्यवस्थित रखें', 'अच्छी रोशनी का उपयोग करें', 'सफाई बनाए रखें']
      },
      donts: {
        en: ['Avoid clutter on desk', 'Don\'t place mirror behind', 'Avoid dark colors', 'Don\'t study facing wall'],
        hi: ['डेस्क पर अव्यवस्था से बचें', 'पीछे आईना न रखें', 'गहरे रंगों से बचें', 'दीवार की ओर मुंह करके न पढ़ें']
      },
      remedies: {
        en: ['Place crystal on desk', 'Use green plants', 'Keep inspiring quotes', 'Use natural light'],
        hi: ['डेस्क पर क्रिस्टल रखें', 'हरे पौधों का उपयोग करें', 'प्रेरणादायक उद्धरण रखें', 'प्राकृतिक प्रकाश का उपयोग करें']
      },
      colors: {
        en: ['White', 'Light Green', 'Light Blue', 'Cream'],
        hi: ['सफेद', 'हल्का हरा', 'हल्का नीला', 'क्रीम']
      }
    }
  ];

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  if (selectedRoom) {
    const room = rooms.find(r => r.id === selectedRoom);
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50">
        {/* Header */}
        <div className="bg-white shadow-sm border-b">
          <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <Link href="/" className="flex items-center space-x-3 cursor-pointer">
                <div className="w-10 h-10 bg-gradient-to-r from-orange-400 to-amber-500 rounded-full flex items-center justify-center">
                  <i className="ri-home-heart-line text-white text-xl"></i>
                </div>
                <h1 className="text-2xl font-bold text-orange-600" style={{fontFamily: 'Pacifico, serif'}}>
                  VastuGuide
                </h1>
              </Link>
            </div>
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-2 px-4 py-2 bg-orange-100 hover:bg-orange-200 rounded-full transition-colors cursor-pointer"
            >
              <i className="ri-translate-2 text-orange-600"></i>
              <span className="text-orange-600 font-medium whitespace-nowrap">
                {language === 'en' ? 'हिंदी' : 'English'}
              </span>
            </button>
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-4 py-8">
          <button
            onClick={() => setSelectedRoom(null)}
            className="flex items-center space-x-2 text-orange-600 hover:text-orange-700 mb-6 cursor-pointer"
          >
            <i className="ri-arrow-left-line"></i>
            <span>{content[language].back}</span>
          </button>

          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className={`bg-gradient-to-r ${room.color} p-8 text-white`}>
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center">
                  <i className={`${room.icon} text-3xl`}></i>
                </div>
                <div>
                  <h2 className="text-3xl font-bold">{room.name[language]}</h2>
                  <p className="opacity-90">{content[language].idealDirection}: {room.idealDirection[language]}</p>
                </div>
              </div>
            </div>

            <div className="p-8 space-y-8">
              {/* Do's */}
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  {content[language].dos}
                </h3>
                <ul className="space-y-2">
                  {room.dos[language].map((item, index) => (
                    <li key={index} className="flex items-start">
                      <i className="ri-arrow-right-s-line text-green-500 mt-1 mr-2"></i>
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Don'ts */}
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-close-line text-red-500 mr-2"></i>
                  {content[language].donts}
                </h3>
                <ul className="space-y-2">
                  {room.donts[language].map((item, index) => (
                    <li key={index} className="flex items-start">
                      <i className="ri-arrow-right-s-line text-red-500 mt-1 mr-2"></i>
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Remedies */}
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-magic-line text-purple-500 mr-2"></i>
                  {content[language].remedies}
                </h3>
                <ul className="space-y-2">
                  {room.remedies[language].map((item, index) => (
                    <li key={index} className="flex items-start">
                      <i className="ri-arrow-right-s-line text-purple-500 mt-1 mr-2"></i>
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Colors */}
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-palette-line text-orange-500 mr-2"></i>
                  {content[language].colors}
                </h3>
                <div className="flex flex-wrap gap-3">
                  {room.colors[language].map((color, index) => (
                    <span key={index} className="px-4 py-2 bg-orange-100 text-orange-700 rounded-full text-sm">
                      {color}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <Link href="/" className="flex items-center space-x-3 cursor-pointer">
              <div className="w-10 h-10 bg-gradient-to-r from-orange-400 to-amber-500 rounded-full flex items-center justify-center">
                <i className="ri-home-heart-line text-white text-xl"></i>
              </div>
              <h1 className="text-2xl font-bold text-orange-600" style={{fontFamily: 'Pacifico, serif'}}>
                VastuGuide
              </h1>
            </Link>
          </div>
          <button
            onClick={toggleLanguage}
            className="flex items-center space-x-2 px-4 py-2 bg-orange-100 hover:bg-orange-200 rounded-full transition-colors cursor-pointer"
          >
            <i className="ri-translate-2 text-orange-600"></i>
            <span className="text-orange-600 font-medium whitespace-nowrap">
              {language === 'en' ? 'हिंदी' : 'English'}
            </span>
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">{content[language].title}</h2>
          <p className="text-xl text-gray-600">{content[language].subtitle}</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rooms.map((room) => (
            <div
              key={room.id}
              onClick={() => setSelectedRoom(room.id)}
              className="bg-white rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer group border border-orange-100 hover:border-orange-300"
            >
              <div className={`bg-gradient-to-r ${room.color} p-6 rounded-t-2xl`}>
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-4">
                  <i className={`${room.icon} text-white text-2xl`}></i>
                </div>
                <h3 className="text-xl font-bold text-white">{room.name[language]}</h3>
                <p className="text-white/80 text-sm mt-1">
                  {content[language].idealDirection}: {room.idealDirection[language]}
                </p>
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Click to view details</span>
                  <i className="ri-arrow-right-line text-orange-500 group-hover:translate-x-1 transition-transform"></i>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}