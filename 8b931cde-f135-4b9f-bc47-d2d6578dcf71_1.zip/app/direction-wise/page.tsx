'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function DirectionWise() {
  const [language, setLanguage] = useState('en');
  const [selectedDirection, setSelectedDirection] = useState(null);

  const content = {
    en: {
      title: 'Direction-wise Vastu',
      subtitle: 'Learn About Directional Vastu Principles',
      idealUsage: 'Ideal Usage',
      avoid: 'Things to Avoid',
      colors: 'Suitable Colors',
      energyTips: 'Energy Tips',
      back: 'Back to Directions'
    },
    hi: {
      title: 'दिशा के अनुसार वास्तु',
      subtitle: 'दिशा संबंधी वास्तु सिद्धांतों के बारे में जानें',
      idealUsage: 'आदर्श उपयोग',
      avoid: 'बचने योग्य बातें',
      colors: 'उपयुक्त रंग',
      energyTips: 'ऊर्जा के सुझाव',
      back: 'दिशाओं पर वापस जाएं'
    }
  };

  const directions = [
    {
      id: 'north',
      name: { en: 'North', hi: 'उत्तर' },
      icon: 'ri-navigation-line',
      color: 'from-blue-400 to-cyan-500',
      element: { en: 'Water', hi: 'जल' },
      deity: { en: 'Kubera (God of Wealth)', hi: 'कुबेर (धन के देवता)' },
      idealUsage: {
        en: ['Main entrance', 'Cash counter', 'Safe/locker', 'Water features', 'Study area'],
        hi: ['मुख्य प्रवेश द्वार', 'कैश काउंटर', 'तिजोरी/लॉकर', 'जल सुविधाएं', 'अध्ययन क्षेत्र']
      },
      avoid: {
        en: ['Heavy structures', 'Toilet/bathroom', 'Kitchen', 'Staircase', 'Overhead tank'],
        hi: ['भारी संरचनाएं', 'शौचालय/स्नानघर', 'रसोई', 'सीढ़ी', 'ओवर हेड टैंक']
      },
      colors: {
        en: ['Blue', 'White', 'Light Green', 'Silver'],
        hi: ['नीला', 'सफेद', 'हल्का हरा', 'चांदी']
      },
      energyTips: {
        en: ['Keep this area clean and clutter-free', 'Place a water fountain', 'Use blue or white colors', 'Keep doors and windows open'],
        hi: ['इस क्षेत्र को साफ और व्यवस्थित रखें', 'पानी का फव्वारा रखें', 'नीले या सफेद रंग का उपयोग करें', 'दरवाजे और खिड़कियां खुली रखें']
      }
    },
    {
      id: 'northeast',
      name: { en: 'North-East', hi: 'उत्तर-पूर्व' },
      icon: 'ri-compass-3-line',
      color: 'from-yellow-400 to-orange-500',
      element: { en: 'Water + Air', hi: 'जल + वायु' },
      deity: { en: 'Lord Shiva', hi: 'भगवान शिव' },
      idealUsage: {
        en: ['Pooja room', 'Meditation area', 'Water storage', 'Garden', 'Open space'],
        hi: ['पूजा कक्ष', 'ध्यान क्षेत्र', 'जल भंडारण', 'बगीचा', 'खुला स्थान']
      },
      avoid: {
        en: ['Toilet/bathroom', 'Kitchen', 'Heavy furniture', 'Staircase', 'Underground water tank'],
        hi: ['शौचालय/स्नानघर', 'रसोई', 'भारी फर्नीचर', 'सीढ़ी', 'भूमिगत पानी की टंकी']
      },
      colors: {
        en: ['White', 'Light Yellow', 'Light Blue', 'Crystal'],
        hi: ['सफेद', 'हल्का पीला', 'हल्का नीला', 'क्रिस्टल']
      },
      energyTips: {
        en: ['Keep this corner bright and airy', 'Place crystals or gemstones', 'Use natural light', 'Keep fresh flowers'],
        hi: ['इस कोने को उज्ज्वल और हवादार रखें', 'क्रिस्टल या रत्न रखें', 'प्राकृतिक प्रकाश का उपयोग करें', 'ताजे फूल रखें']
      }
    },
    {
      id: 'east',
      name: { en: 'East', hi: 'पूर्व' },
      icon: 'ri-sun-line',
      color: 'from-orange-400 to-red-500',
      element: { en: 'Air', hi: 'वायु' },
      deity: { en: 'Lord Indra (King of Gods)', hi: 'भगवान इंद्र (देवराज)' },
      idealUsage: {
        en: ['Main entrance', 'Living room', 'Balcony', 'Windows', 'Garden'],
        hi: ['मुख्य प्रवेश द्वार', 'बैठक', 'बालकनी', 'खिड़कियां', 'बगीचा']
      },
      avoid: {
        en: ['Heavy structures', 'Toilet', 'Storage room', 'Staircase', 'Overhead structures'],
        hi: ['भारी संरचनाएं', 'शौचालय', 'भंडारण कक्ष', 'सीढ़ी', 'ऊपरी संरचनाएं']
      },
      colors: {
        en: ['Orange', 'Yellow', 'Light Red', 'Golden'],
        hi: ['नारंगी', 'पीला', 'हल्का लाल', 'सुनहरा']
      },
      energyTips: {
        en: ['Welcome morning sunlight', 'Use bright colors', 'Keep windows clean', 'Place plants here'],
        hi: ['सुबह की धूप का स्वागत करें', 'चमकीले रंगों का उपयोग करें', 'खिड़कियों को साफ रखें', 'यहां पौधे रखें']
      }
    },
    {
      id: 'southeast',
      name: { en: 'South-East', hi: 'दक्षिण-पूर्व' },
      icon: 'ri-fire-line',
      color: 'from-red-400 to-pink-500',
      element: { en: 'Fire', hi: 'अग्नि' },
      deity: { en: 'Lord Agni (Fire God)', hi: 'भगवान अग्नि (अग्नि देव)' },
      idealUsage: {
        en: ['Kitchen', 'Electrical appliances', 'Generator room', 'Fireplace', 'Gas connection'],
        hi: ['रसोई', 'विद्युत उपकरण', 'जेनेरेटर रूम', 'चिमनी', 'गैस कनेक्शन']
      },
      avoid: {
        en: ['Water storage', 'Toilet', 'Bedroom', 'Study room', 'Pooja room'],
        hi: ['जल भंडारण', 'शौचालय', 'शयनकक्ष', 'अध्ययन कक्ष', 'पूजा कक्ष']
      },
      colors: {
        en: ['Red', 'Orange', 'Pink', 'Bright Yellow'],
        hi: ['लाल', 'नारंगी', 'गुलाबी', 'चमकीला पीला']
      },
      energyTips: {
        en: ['Keep fire elements here', 'Use warm colors', 'Ensure proper ventilation', 'Place red flowers'],
        hi: ['यहां अग्नि तत्व रखें', 'गर्म रंगों का उपयोग करें', 'उचित वेंटिलेशन सुनिश्चित करें', 'लाल फूल रखें']
      }
    },
    {
      id: 'south',
      name: { en: 'South', hi: 'दक्षिण' },
      icon: 'ri-arrow-down-line',
      color: 'from-green-400 to-teal-500',
      element: { en: 'Earth', hi: 'पृथ्वी' },
      deity: { en: 'Lord Yama (God of Death)', hi: 'भगवान यम (मृत्यु के देवता)' },
      idealUsage: {
        en: ['Heavy furniture', 'Storage room', 'Master bedroom', 'Staircase', 'High walls'],
        hi: ['भारी फर्नीचर', 'भंडारण कक्ष', 'मुख्य शयनकक्ष', 'सीढ़ी', 'ऊंची दीवारें']
      },
      avoid: {
        en: ['Main entrance', 'Pooja room', 'Kitchen', 'Water features', 'Open spaces'],
        hi: ['मुख्य प्रवेश द्वार', 'पूजा कक्ष', 'रसोई', 'जल सुविधाएं', 'खुले स्थान']
      },
      colors: {
        en: ['Dark Green', 'Brown', 'Maroon', 'Dark Blue'],
        hi: ['गहरा हरा', 'भूरा', 'मैरून', 'गहरा नीला']
      },
      energyTips: {
        en: ['Keep heavy objects here', 'Use earth tones', 'Maintain higher elevation', 'Place indoor plants'],
        hi: ['यहां भारी वस्तुएं रखें', 'मिट्टी के रंगों का उपयोग करें', 'अधिक ऊंचाई बनाए रखें', 'इनडोर पौधे रखें']
      }
    },
    {
      id: 'southwest',
      name: { en: 'South-West', hi: 'दक्षिण-पश्चिम' },
      icon: 'ri-shield-line',
      color: 'from-purple-400 to-indigo-500',
      element: { en: 'Earth + Air', hi: 'पृथ्वी + वायु' },
      deity: { en: 'Pitru (Ancestors)', hi: 'पितृ (पूर्वज)' },
      idealUsage: {
        en: ['Master bedroom', 'Heavy storage', 'Safe/locker', 'Staircase', 'High structures'],
        hi: ['मुख्य शयनकक्ष', 'भारी भंडारण', 'तिजोरी/लॉकर', 'सीढ़ी', 'ऊंची संरचनाएं']
      },
      avoid: {
        en: ['Main entrance', 'Kitchen', 'Pooja room', 'Children bedroom', 'Open spaces'],
        hi: ['मुख्य प्रवेश द्वार', 'रसोई', 'पूजा कक्ष', 'बच्चों का शयनकक्ष', 'खुले स्थान']
      },
      colors: {
        en: ['Brown', 'Yellow', 'Orange', 'Beige'],
        hi: ['भूरा', 'पीला', 'नारंगी', 'बेज']
      },
      energyTips: {
        en: ['Keep this area heavy and stable', 'Use warm earth colors', 'Place family photos', 'Maintain good height'],
        hi: ['इस क्षेत्र को भारी और स्थिर रखें', 'गर्म मिट्टी के रंगों का उपयोग करें', 'पारिवारिक तस्वीरें रखें', 'अच्छी ऊंचाई बनाए रखें']
      }
    },
    {
      id: 'west',
      name: { en: 'West', hi: 'पश्चिम' },
      icon: 'ri-arrow-left-line',
      color: 'from-gray-400 to-blue-500',
      element: { en: 'Air + Water', hi: 'वायु + जल' },
      deity: { en: 'Lord Varuna (God of Water)', hi: 'भगवान वरुण (जल के देवता)' },
      idealUsage: {
        en: ['Bathroom', 'Toilet', 'Storage', 'Dining room', 'Staircase'],
        hi: ['स्नानघर', 'शौचालय', 'भंडारण', 'भोजन कक्ष', 'सीढ़ी']
      },
      avoid: {
        en: ['Main entrance', 'Pooja room', 'Master bedroom', 'Kitchen', 'Study room'],
        hi: ['मुख्य प्रवेश द्वार', 'पूजा कक्ष', 'मुख्य शयनकक्ष', 'रसोई', 'अध्ययन कक्ष']
      },
      colors: {
        en: ['White', 'Blue', 'Gray', 'Silver'],
        hi: ['सफेद', 'नीला', 'स्लेटी', 'चांदी']
      },
      energyTips: {
        en: ['Keep this area cool and calm', 'Use light colors', 'Ensure proper drainage', 'Place water elements'],
        hi: ['इस क्षेत्र को ठंडा और शांत रखें', 'हल्के रंगों का उपयोग करें', 'उचित जल निकासी सुनिश्चित करें', 'जल तत्व रखें']
      }
    },
    {
      id: 'northwest',
      name: { en: 'North-West', hi: 'उत्तर-पश्चिम' },
      icon: 'ri-windy-line',
      color: 'from-teal-400 to-cyan-500',
      element: { en: 'Air', hi: 'वायु' },
      deity: { en: 'Lord Vayu (Wind God)', hi: 'भगवान वायु (पवन देव)' },
      idealUsage: {
        en: ['Guest room', 'Bathroom', 'Storage', 'Car parking', 'Service rooms'],
        hi: ['अतिथि कक्ष', 'स्नानघर', 'भंडारण', 'कार पार्किंग', 'सेवा कक्ष']
      },
      avoid: {
        en: ['Master bedroom', 'Pooja room', 'Kitchen', 'Heavy structures', 'Main entrance'],
        hi: ['मुख्य शयनकक्ष', 'पूजा कक्ष', 'रसोई', 'भारी संरचनाएं', 'मुख्य प्रवेश द्वार']
      },
      colors: {
        en: ['White', 'Light Blue', 'Gray', 'Metallic'],
        hi: ['सफेद', 'हल्का नीला', 'स्लेटी', 'धातु']
      },
      energyTips: {
        en: ['Keep air circulation good', 'Use wind chimes', 'Maintain movement energy', 'Keep it light and airy'],
        hi: ['हवा का संचार अच्छा रखें', 'विंड चाइम्स का उपयोग करें', 'गति ऊर्जा बनाए रखें', 'इसे हल्का और हवादार रखें']
      }
    }
  ];

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  if (selectedDirection) {
    const direction = directions.find(d => d.id === selectedDirection);
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50">
        {/* Header */}
        <div className="bg-white shadow-sm border-b">
          <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <Link href="/" className="flex items-center space-x-3 cursor-pointer">
                <div className="w-10 h-10 bg-gradient-to-r from-orange-400 to-amber-500 rounded-full flex items-center justify-center">
                  <i className="ri-home-heart-line text-white text-xl"></i>
                </div>
                <h1 className="text-2xl font-bold text-orange-600" style={{fontFamily: 'Pacifico, serif'}}>
                  VastuGuide
                </h1>
              </Link>
            </div>
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-2 px-4 py-2 bg-orange-100 hover:bg-orange-200 rounded-full transition-colors cursor-pointer"
            >
              <i className="ri-translate-2 text-orange-600"></i>
              <span className="text-orange-600 font-medium whitespace-nowrap">
                {language === 'en' ? 'हिंदी' : 'English'}
              </span>
            </button>
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-4 py-8">
          <button
            onClick={() => setSelectedDirection(null)}
            className="flex items-center space-x-2 text-orange-600 hover:text-orange-700 mb-6 cursor-pointer"
          >
            <i className="ri-arrow-left-line"></i>
            <span>{content[language].back}</span>
          </button>

          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className={`bg-gradient-to-r ${direction.color} p-8 text-white`}>
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center">
                  <i className={`${direction.icon} text-3xl`}></i>
                </div>
                <div>
                  <h2 className="text-3xl font-bold">{direction.name[language]}</h2>
                  <p className="opacity-90">Element: {direction.element[language]} | Deity: {direction.deity[language]}</p>
                </div>
              </div>
            </div>

            <div className="p-8 space-y-8">
              {/* Ideal Usage */}
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-check-line text-green-500 mr-2"></i>
                  {content[language].idealUsage}
                </h3>
                <ul className="grid md:grid-cols-2 gap-2">
                  {direction.idealUsage[language].map((item, index) => (
                    <li key={index} className="flex items-center">
                      <i className="ri-arrow-right-s-line text-green-500 mr-2"></i>
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Things to Avoid */}
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-close-line text-red-500 mr-2"></i>
                  {content[language].avoid}
                </h3>
                <ul className="grid md:grid-cols-2 gap-2">
                  {direction.avoid[language].map((item, index) => (
                    <li key={index} className="flex items-center">
                      <i className="ri-arrow-right-s-line text-red-500 mr-2"></i>
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Colors */}
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-palette-line text-orange-500 mr-2"></i>
                  {content[language].colors}
                </h3>
                <div className="flex flex-wrap gap-3">
                  {direction.colors[language].map((color, index) => (
                    <span key={index} className="px-4 py-2 bg-orange-100 text-orange-700 rounded-full text-sm">
                      {color}
                    </span>
                  ))}
                </div>
              </div>

              {/* Energy Tips */}
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-lightbulb-line text-purple-500 mr-2"></i>
                  {content[language].energyTips}
                </h3>
                <ul className="space-y-2">
                  {direction.energyTips[language].map((tip, index) => (
                    <li key={index} className="flex items-start">
                      <i className="ri-arrow-right-s-line text-purple-500 mt-1 mr-2"></i>
                      <span className="text-gray-700">{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <Link href="/" className="flex items-center space-x-3 cursor-pointer">
              <div className="w-10 h-10 bg-gradient-to-r from-orange-400 to-amber-500 rounded-full flex items-center justify-center">
                <i className="ri-home-heart-line text-white text-xl"></i>
              </div>
              <h1 className="text-2xl font-bold text-orange-600" style={{fontFamily: 'Pacifico, serif'}}>
                VastuGuide
              </h1>
            </Link>
          </div>
          <button
            onClick={toggleLanguage}
            className="flex items-center space-x-2 px-4 py-2 bg-orange-100 hover:bg-orange-200 rounded-full transition-colors cursor-pointer"
          >
            <i className="ri-translate-2 text-orange-600"></i>
            <span className="text-orange-600 font-medium whitespace-nowrap">
              {language === 'en' ? 'हिंदी' : 'English'}
            </span>
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">{content[language].title}</h2>
          <p className="text-xl text-gray-600">{content[language].subtitle}</p>
        </div>

        {/* Compass */}
        <div className="mb-12 flex justify-center">
          <div className="relative w-80 h-80 bg-white rounded-full shadow-lg border-4 border-orange-200">
            <div className="absolute inset-4 rounded-full border-2 border-orange-300">
              {directions.map((direction, index) => {
                const angle = index * 45;
                const radius = 120;
                const x = Math.cos((angle - 90) * Math.PI / 180) * radius;
                const y = Math.sin((angle - 90) * Math.PI / 180) * radius;
                
                return (
                  <button
                    key={direction.id}
                    onClick={() => setSelectedDirection(direction.id)}
                    className="absolute w-16 h-16 bg-gradient-to-r from-orange-400 to-amber-500 rounded-full flex items-center justify-center text-white font-bold shadow-lg hover:shadow-xl transition-all cursor-pointer transform hover:scale-110"
                    style={{
                      transform: `translate(${x + 120}px, ${y + 120}px)`
                    }}
                  >
                    <span className="text-xs text-center whitespace-nowrap">
                      {direction.name[language]}
                    </span>
                  </button>
                );
              })}
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                <i className="ri-compass-line text-white"></i>
              </div>
            </div>
          </div>
        </div>

        {/* Direction Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {directions.map((direction) => (
            <div
              key={direction.id}
              onClick={() => setSelectedDirection(direction.id)}
              className="bg-white rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer group border border-orange-100 hover:border-orange-300"
            >
              <div className={`bg-gradient-to-r ${direction.color} p-6 rounded-t-2xl`}>
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-4">
                  <i className={`${direction.icon} text-white text-2xl`}></i>
                </div>
                <h3 className="text-xl font-bold text-white">{direction.name[language]}</h3>
                <p className="text-white/80 text-sm mt-1">{direction.element[language]}</p>
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Click to explore</span>
                  <i className="ri-arrow-right-line text-orange-500 group-hover:translate-x-1 transition-transform"></i>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}