'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Remedies() {
  const [language, setLanguage] = useState('en');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const content = {
    en: {
      title: 'Vastu Remedies',
      subtitle: 'Effective Solutions for Vastu Doshas',
      allCategories: 'All Remedies',
      searchPlaceholder: 'Search remedies...',
      difficulty: 'Difficulty',
      timeRequired: 'Time Required',
      materials: 'Materials Needed',
      steps: 'Steps to Follow',
      benefits: 'Benefits',
      easy: 'Easy',
      medium: 'Medium',
      advanced: 'Advanced'
    },
    hi: {
      title: 'वास्तु के उपाय',
      subtitle: 'वास्तु दोषों के लिए प्रभावी समाधान',
      allCategories: 'सभी उपाय',
      searchPlaceholder: 'उपाय खोजें...',
      difficulty: 'कठिनाई',
      timeRequired: 'समय की आवश्यकता',
      materials: 'आवश्यक सामग्री',
      steps: 'अनुसरण करने के चरण',
      benefits: 'लाभ',
      easy: 'आसान',
      medium: 'मध्यम',
      advanced: 'उन्नत'
    }
  };

  const categories = [
    { id: 'all', name: { en: 'All Remedies', hi: 'सभी उपाय' } },
    { id: 'entrance', name: { en: 'Entrance', hi: 'प्रवेश द्वार' } },
    { id: 'kitchen', name: { en: 'Kitchen', hi: 'रसोई' } },
    { id: 'bedroom', name: { en: 'Bedroom', hi: 'शयनकक्ष' } },
    { id: 'bathroom', name: { en: 'Bathroom', hi: 'स्नानघर' } },
    { id: 'general', name: { en: 'General', hi: 'सामान्य' } }
  ];

  const remedies = [
    {
      id: 1,
      category: 'entrance',
      title: { en: 'Main Door Remedy', hi: 'मुख्य द्वार का उपाय' },
      problem: { 
        en: 'Main door facing South or South-West', 
        hi: 'मुख्य द्वार दक्षिण या दक्षिण-पश्चिम की ओर है' 
      },
      difficulty: 'easy',
      timeRequired: { en: '30 minutes', hi: '30 मिनट' },
      materials: {
        en: ['Red cloth or mat', 'Brass nameplate', 'Toran (door hanging)', 'Swastik symbol'],
        hi: ['लाल कपड़ा या चटाई', 'पीतल की नेमप्लेट', 'तोरण (दरवाजे की लटकन)', 'स्वास्तिक चिन्ह']
      },
      steps: {
        en: [
          'Place a red mat or cloth at the entrance',
          'Install a brass nameplate on the right side',
          'Hang a traditional toran above the door',
          'Draw or place a Swastik symbol on the door'
        ],
        hi: [
          'प्रवेश द्वार पर लाल चटाई या कपड़ा रखें',
          'दाईं ओर पीतल की नेमप्लेट लगाएं',
          'दरवाजे के ऊपर पारंपरिक तोरण लटकाएं',
          'दरवाजे पर स्वास्तिक चिन्ह बनाएं या रखें'
        ]
      },
      benefits: {
        en: ['Attracts positive energy', 'Reduces negative influences', 'Brings prosperity'],
        hi: ['सकारात्मक ऊर्जा आकर्षित करता है', 'नकारात्मक प्रभावों को कम करता है', 'समृद्धि लाता है']
      },
      icon: 'ri-door-open-line',
      color: 'from-red-400 to-orange-500'
    },
    {
      id: 2,
      category: 'kitchen',
      title: { en: 'Kitchen Direction Remedy', hi: 'रसोई दिशा का उपाय' },
      problem: { 
        en: 'Kitchen in North or North-East direction', 
        hi: 'रसोई उत्तर या उत्तर-पूर्व दिशा में है' 
      },
      difficulty: 'medium',
      timeRequired: { en: '1 hour', hi: '1 घंटा' },
      materials: {
        en: ['Red flowers', 'Pyramid', 'Red bulb/light', 'Sea salt', 'Camphor'],
        hi: ['लाल फूल', 'पिरामिड', 'लाल बल्ब/रोशनी', 'समुद्री नमक', 'कपूर']
      },
      steps: {
        en: [
          'Place red flowers in South-East corner of kitchen',
          'Install a small pyramid on the cooking platform',
          'Use red colored bulb in the kitchen',
          'Sprinkle sea salt in corners and clean after 24 hours',
          'Burn camphor daily for purification'
        ],
        hi: [
          'रसोई के दक्षिण-पूर्व कोने में लाल फूल रखें',
          'खाना बनाने के प्लेटफॉर्म पर एक छोटा पिरामिड रखें',
          'रसोई में लाल रंग का बल्ब उपयोग करें',
          'कोनों में समुद्री नमक छिड़कें और 24 घंटे बाद साफ करें',
          'शुद्धिकरण के लिए रोजाना कपूर जलाएं'
        ]
      },
      benefits: {
        en: ['Balances fire element', 'Improves health', 'Reduces kitchen accidents'],
        hi: ['अग्नि तत्व को संतुलित करता है', 'स्वास्थ्य में सुधार करता है', 'रसोई की दुर्घटनाओं को कम करता है']
      },
      icon: 'ri-restaurant-line',
      color: 'from-orange-400 to-red-500'
    },
    {
      id: 3,
      category: 'bedroom',
      title: { en: 'Bedroom Energy Remedy', hi: 'शयनकक्ष ऊर्जा का उपाय' },
      problem: { 
        en: 'Disturbed sleep and relationship issues', 
        hi: 'नींद में परेशानी और रिश्तों की समस्याएं' 
      },
      difficulty: 'easy',
      timeRequired: { en: '45 minutes', hi: '45 मिनट' },
      materials: {
        en: ['Rose quartz crystals', 'Lavender oil', 'Pink or light blue curtains', 'Pair decorative items'],
        hi: ['गुलाब क्वार्ट्ज क्रिस्टल', 'लैवेंडर तेल', 'गुलाबी या हल्के नीले पर्दे', 'जोड़े की सजावटी वस्तुएं']
      },
      steps: {
        en: [
          'Place rose quartz crystals on both sides of the bed',
          'Use lavender oil diffuser for calming effect',
          'Install light colored curtains to soften energy',
          'Keep decorative items in pairs (candles, photo frames)',
          'Remove mirrors facing the bed'
        ],
        hi: [
          'बिस्तर के दोनों तरफ गुलाब क्वार्ट्ज क्रिस्टल रखें',
          'शांत प्रभाव के लिए लैवेंडर तेल डिफ्यूजर का उपयोग करें',
          'ऊर्जा को नरम करने के लिए हल्के रंग के पर्दे लगाएं',
          'सजावटी वस्तुओं को जोड़ों में रखें (मोमबत्तियां, फोटो फ्रेम)',
          'बिस्तर के सामने के आईने हटाएं'
        ]
      },
      benefits: {
        en: ['Improves sleep quality', 'Enhances relationships', 'Creates peaceful environment'],
        hi: ['नींद की गुणवत्ता में सुधार करता है', 'रिश्तों को बढ़ाता है', 'शांतिपूर्ण वातावरण बनाता है']
      },
      icon: 'ri-hotel-bed-line',
      color: 'from-blue-400 to-purple-500'
    },
    {
      id: 4,
      category: 'bathroom',
      title: { en: 'Bathroom Purification', hi: 'स्नानघर शुद्धिकरण' },
      problem: { 
        en: 'Bathroom in North-East or center of house', 
        hi: 'स्नानघर उत्तर-पूर्व या घर के मध्य में है' 
      },
      difficulty: 'medium',
      timeRequired: { en: '2 hours', hi: '2 घंटे' },
      materials: {
        en: ['Sea salt', 'White sage', 'Green plants', 'Exhaust fan', 'Light colors paint'],
        hi: ['समुद्री नमक', 'सफेद सेज', 'हरे पौधे', 'एग्जॉस्ट फैन', 'हल्के रंग का पेंट']
      },
      steps: {
        en: [
          'Deep clean the bathroom with sea salt water',
          'Burn white sage for spiritual cleansing',
          'Place small green plants outside the bathroom',
          'Install powerful exhaust fan for air circulation',
          'Paint walls in light, soothing colors',
          'Keep bathroom door closed always'
        ],
        hi: [
          'समुद्री नमक के पानी से स्नानघर की गहरी सफाई करें',
          'आध्यात्मिक सफाई के लिए सफेद सेज जलाएं',
          'स्नानघर के बाहर छोटे हरे पौधे रखें',
          'हवा के संचार के लिए शक्तिशाली एग्जॉस्ट फैन लगाएं',
          'दीवारों को हल्के, शांत रंगों में रंगें',
          'स्नानघर का दरवाजा हमेशा बंद रखें'
        ]
      },
      benefits: {
        en: ['Neutralizes negative energy', 'Improves health', 'Maintains hygiene'],
        hi: ['नकारात्मक ऊर्जा को बेअसर करता है', 'स्वास्थ्य में सुधार करता है', 'स्वच्छता बनाए रखता है']
      },
      icon: 'ri-drop-line',
      color: 'from-cyan-400 to-blue-500'
    },
    {
      id: 5,
      category: 'general',
      title: { en: 'Crystal Pyramid Remedy', hi: 'क्रिस्टल पिरामिड उपाय' },
      problem: { 
        en: 'General negative energy in house', 
        hi: 'घर में सामान्य नकारात्मक ऊर्जा' 
      },
      difficulty: 'easy',
      timeRequired: { en: '20 minutes', hi: '20 मिनट' },
      materials: {
        en: ['Clear quartz pyramid', 'Copper plate', 'Rock salt', 'Red cloth'],
        hi: ['स्पष्ट क्वार्ट्ज पिरामिड', 'तांबे की प्लेट', 'सेंधा नमक', 'लाल कपड़ा']
      },
      steps: {
        en: [
          'Place pyramid on copper plate in center of house',
          'Surround with rock salt in circular pattern',
          'Cover with red cloth during eclipse or negative events',
          'Clean pyramid weekly with running water',
          'Rotate pyramid 45 degrees weekly'
        ],
        hi: [
          'घर के मध्य में तांबे की प्लेट पर पिरामिड रखें',
          'गोलाकार पैटर्न में सेंधा नमक से घेरें',
          'ग्रहण या नकारात्मक घटनाओं के दौरान लाल कपड़े से ढकें',
          'बहते पानी से साप्ताहिक पिरामिड साफ करें',
          'साप्ताहिक पिरामिड को 45 डिग्री घुमाएं'
        ]
      },
      benefits: {
        en: ['Purifies entire house energy', 'Attracts positivity', 'Balances all elements'],
        hi: ['पूरे घर की ऊर्जा को शुद्ध करता है', 'सकारात्मकता आकर्षित करता है', 'सभी तत्वों को संतुलित करता है']
      },
      icon: 'ri-pyramid-line',
      color: 'from-purple-400 to-indigo-500'
    },
    {
      id: 6,
      category: 'general',
      title: { en: 'Salt Water Remedy', hi: 'नमकीन पानी का उपाय' },
      problem: { 
        en: 'Heavy negative energy and obstacles', 
        hi: 'भारी नकारात्मक ऊर्जा और बाधाएं' 
      },
      difficulty: 'easy',
      timeRequired: { en: '15 minutes daily', hi: '15 मिनट रोजाना' },
      materials: {
        en: ['Sea salt', 'Glass bowl', 'Fresh water', 'White candle'],
        hi: ['समुद्री नमक', 'कांच का कटोरा', 'ताजा पानी', 'सफेद मोमबत्ती']
      },
      steps: {
        en: [
          'Fill glass bowl with fresh water',
          'Add 2 tablespoons of sea salt',
          'Place in problem area or center of house',
          'Light white candle nearby',
          'Replace water every 3 days',
          'Dispose old water in flowing drain'
        ],
        hi: [
          'कांच के कटोरे में ताजा पानी भरें',
          '2 चम्मच समुद्री नमक डालें',
          'समस्या वाले स्थान या घर के मध्य में रखें',
          'पास में सफेद मोमबत्ती जलाएं',
          'हर 3 दिन में पानी बदलें',
          'पुराना पानी बहते नाले में बहाएं'
        ]
      },
      benefits: {
        en: ['Absorbs negative energy', 'Removes obstacles', 'Creates protective barrier'],
        hi: ['नकारात्मक ऊर्जा को अवशोषित करता है', 'बाधाओं को हटाता है', 'सुरक्षात्मक बाधा बनाता है']
      },
      icon: 'ri-water-percent-line',
      color: 'from-teal-400 to-cyan-500'
    }
  ];

  const filteredRemedies = selectedCategory === 'all' 
    ? remedies 
    : remedies.filter(remedy => remedy.category === selectedCategory);

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  const getDifficultyColor = (difficulty) => {
    switch(difficulty) {
      case 'easy': return 'bg-green-100 text-green-700';
      case 'medium': return 'bg-yellow-100 text-yellow-700';
      case 'advanced': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <Link href="/" className="flex items-center space-x-3 cursor-pointer">
              <div className="w-10 h-10 bg-gradient-to-r from-orange-400 to-amber-500 rounded-full flex items-center justify-center">
                <i className="ri-home-heart-line text-white text-xl"></i>
              </div>
              <h1 className="text-2xl font-bold text-orange-600" style={{fontFamily: 'Pacifico, serif'}}>
                VastuGuide
              </h1>
            </Link>
          </div>
          <button
            onClick={toggleLanguage}
            className="flex items-center space-x-2 px-4 py-2 bg-orange-100 hover:bg-orange-200 rounded-full transition-colors cursor-pointer"
          >
            <i className="ri-translate-2 text-orange-600"></i>
            <span className="text-orange-600 font-medium whitespace-nowrap">
              {language === 'en' ? 'हिंदी' : 'English'}
            </span>
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">{content[language].title}</h2>
          <p className="text-xl text-gray-600">{content[language].subtitle}</p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-3 mb-8 justify-center">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-3 rounded-full font-medium transition-colors cursor-pointer whitespace-nowrap ${
                selectedCategory === category.id
                  ? 'bg-orange-500 text-white'
                  : 'bg-white text-orange-600 hover:bg-orange-100'
              }`}
            >
              {category.name[language]}
            </button>
          ))}
        </div>

        {/* Remedies Grid */}
        <div className="grid lg:grid-cols-2 gap-8">
          {filteredRemedies.map((remedy) => (
            <div key={remedy.id} className="bg-white rounded-2xl shadow-lg overflow-hidden border border-orange-100">
              <div className={`bg-gradient-to-r ${remedy.color} p-6 text-white`}>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <i className={`${remedy.icon} text-2xl`}></i>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold">{remedy.title[language]}</h3>
                    <p className="opacity-90 text-sm">{remedy.problem[language]}</p>
                  </div>
                  <div className={`px-3 py-1 bg-white/20 rounded-full text-sm ${getDifficultyColor(remedy.difficulty)}`}>
                    {content[language][remedy.difficulty]}
                  </div>
                </div>
              </div>

              <div className="p-6 space-y-6">
                <div className="flex items-center text-gray-600 text-sm">
                  <i className="ri-time-line mr-2"></i>
                  {content[language].timeRequired}: {remedy.timeRequired[language]}
                </div>

                {/* Materials */}
                <div>
                  <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                    <i className="ri-shopping-bag-line text-orange-500 mr-2"></i>
                    {content[language].materials}
                  </h4>
                  <ul className="space-y-1">
                    {remedy.materials[language].map((material, index) => (
                      <li key={index} className="flex items-start text-sm text-gray-600">
                        <i className="ri-arrow-right-s-line text-orange-500 mt-0.5 mr-1 flex-shrink-0"></i>
                        <span>{material}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Steps */}
                <div>
                  <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                    <i className="ri-list-ordered text-orange-500 mr-2"></i>
                    {content[language].steps}
                  </h4>
                  <ol className="space-y-2">
                    {remedy.steps[language].map((step, index) => (
                      <li key={index} className="flex items-start text-sm text-gray-600">
                        <span className="bg-orange-100 text-orange-600 rounded-full w-5 h-5 flex items-center justify-center text-xs font-medium mr-3 mt-0.5 flex-shrink-0">
                          {index + 1}
                        </span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>

                {/* Benefits */}
                <div>
                  <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                    <i className="ri-star-line text-orange-500 mr-2"></i>
                    {content[language].benefits}
                  </h4>
                  <ul className="space-y-1">
                    {remedy.benefits[language].map((benefit, index) => (
                      <li key={index} className="flex items-start text-sm text-gray-600">
                        <i className="ri-check-line text-green-500 mt-0.5 mr-2 flex-shrink-0"></i>
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}